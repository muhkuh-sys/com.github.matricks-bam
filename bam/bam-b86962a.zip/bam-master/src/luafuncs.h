
/* special tables and places where we store certain variables in lua */
extern const char *CONTEXT_LUA_SCRIPTARGS_TABLE;
extern const char *CONTEXT_LUA_TARGETS_TABLE;
extern const char *CONTEXT_LUA_PATH;
extern const char *CONTEXT_LUA_WORKPATH;

/* jobs and deps */
int lf_add_job(struct lua_State *L);
int lf_add_output(struct lua_State *L);
int lf_add_sideeffect(struct lua_State *L);
int lf_add_clean(struct lua_State *L);
int lf_add_pseudo(struct lua_State *L);
int lf_add_dependency(struct lua_State *L);
int lf_add_constraint_shared(struct lua_State *L);
int lf_add_constraint_exclusive(struct lua_State *L);
int lf_set_filter(struct lua_State *L);
int lf_default_target(struct lua_State *L);
int lf_update_globalstamp(struct lua_State *L);
int lf_nodeexist(struct lua_State *L);

int lf_isoutput(struct lua_State *L);

int lf_set_priority(struct lua_State *L);
int lf_modify_priority(struct lua_State *L);
int lf_skip_output_verification(struct lua_State *L);

/* dependency */
int lf_add_dependency_cpp_set_paths(lua_State *L); /* dep_cpp.c */
int lf_add_dependency_cpp(lua_State *L); /* dep_cpp.c */
int lf_add_dependency_search(lua_State *L); /* dep_search.c */

/* lua file and directory discovery */
int lf_collect(struct lua_State *L);
int lf_collectrecursive(struct lua_State *L);
int lf_collectdirs(struct lua_State *L);
int lf_collectdirsrecursive(struct lua_State *L);
int lf_listdir(struct lua_State *L);

/* path functions  */
int lf_path_isnice(struct lua_State *L);
int lf_path_join(struct lua_State *L);
int lf_path_normalize(struct lua_State *L);

int lf_path_ext(struct lua_State *L);
int lf_path_dir(struct lua_State *L);
int lf_path_base(struct lua_State *L);
int lf_path_filename(struct lua_State *L);

int lf_path_hash(struct lua_State *L);

/* support, files and dirs */
int lf_mkdir(struct lua_State *L);
int lf_mkdirs(struct lua_State *L);
int lf_fileexist(struct lua_State *L);
int lf_isdir(struct lua_State *L);
int lf_isfile(struct lua_State *L);

/* table functions*/
int lf_table_walk(struct lua_State *L);
int lf_table_deepcopy(struct lua_State *L);
int lf_table_tostring(struct lua_State *L);
int lf_table_flatten(struct lua_State *L);

/* support, misc */
int lf_hash(struct lua_State *L);
int lf_istable(struct lua_State *L);
int lf_isstring(struct lua_State *L);
int lf_loadfile(struct lua_State *L);
int lf_errorfunc(struct lua_State *L);
int lf_panicfunc(struct lua_State *L);
int lf_sleep(struct lua_State *L);

