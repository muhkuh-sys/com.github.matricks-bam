AddJob({"output1", "output2"}, "testing 1", "echo hello > output1")
