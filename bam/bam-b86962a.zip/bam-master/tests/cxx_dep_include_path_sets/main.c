#include <system_header.h>
#include "local_header.h"
#include "genereted_header.h"
#include <stdio.h>

int main()
{
	printf("hello world\n");
	return 0;
}
