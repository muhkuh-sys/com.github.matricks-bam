extern const char *get_magic_string();
