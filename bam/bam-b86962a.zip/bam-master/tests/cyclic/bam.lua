s = NewSettings()
Link(s, "cyclic", Compile(s, Collect("*.c")))
